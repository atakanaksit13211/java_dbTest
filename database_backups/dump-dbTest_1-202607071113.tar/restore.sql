--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "dbTest_1";
--
-- Name: dbTest_1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "dbTest_1" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE "dbTest_1" OWNER TO postgres;

\unrestrict (null)
\connect "dbTest_1"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    address_id integer NOT NULL,
    address character varying NOT NULL,
    city character varying NOT NULL,
    county character varying NOT NULL,
    post_code character varying NOT NULL
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: TABLE address; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.address IS 'adress for a user';


--
-- Name: address_address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.address ALTER COLUMN address_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.address_address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book (
    book_id integer NOT NULL,
    title character varying NOT NULL,
    author character varying NOT NULL,
    isbn character varying NOT NULL,
    publisher character varying NOT NULL
);


ALTER TABLE public.book OWNER TO postgres;

--
-- Name: TABLE book; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.book IS 'book information';


--
-- Name: COLUMN book.isbn; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.book.isbn IS 'types like int will remove leading 0''s';


--
-- Name: book_book_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.book ALTER COLUMN book_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.book_book_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: borrowing; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.borrowing (
    borrowing_id integer NOT NULL,
    borrowed_timestamp timestamp with time zone NOT NULL,
    due_timestamp timestamp with time zone NOT NULL,
    book_id integer NOT NULL,
    user_id integer NOT NULL,
    returned boolean NOT NULL
);


ALTER TABLE public.borrowing OWNER TO postgres;

--
-- Name: COLUMN borrowing.borrowed_timestamp; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.borrowing.borrowed_timestamp IS 'time that the book got borrowed. Internally stored as UTC but will give time on postgre session time zone. When uploading time, please also give time zone so we can store things cleanly';


--
-- Name: COLUMN borrowing.due_timestamp; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.borrowing.due_timestamp IS 'time that the book is due';


--
-- Name: COLUMN borrowing.book_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.borrowing.book_id IS 'book that got borrowed';


--
-- Name: COLUMN borrowing.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.borrowing.user_id IS 'user that borrowed the book';


--
-- Name: COLUMN borrowing.returned; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.borrowing.returned IS 'did the book get returned, making this borrowing a past record (the current records get turned into past record with this. a book might get borrowed and then never returned past the due date. Or it might be a late return, so we cannot choose on due time)';


--
-- Name: borrowing_borrowing_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.borrowing ALTER COLUMN borrowing_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.borrowing_borrowing_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: contact_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_information (
    contact_information_id integer NOT NULL,
    primary_phone_number character varying NOT NULL,
    alternative_email character varying
);


ALTER TABLE public.contact_information OWNER TO postgres;

--
-- Name: TABLE contact_information; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.contact_information IS 'contact information for a user';


--
-- Name: COLUMN contact_information.primary_phone_number; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.contact_information.primary_phone_number IS 'primary phone number. In case of needing multiple numbers, create a new table';


--
-- Name: contact_information_contact_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.contact_information ALTER COLUMN contact_information_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.contact_information_contact_information_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    user_name character varying NOT NULL COLLATE pg_catalog."C.utf8",
    password_salt character varying NOT NULL,
    password_hash character varying NOT NULL,
    email_address character varying NOT NULL,
    user_id integer NOT NULL,
    address_id integer,
    contact_information_id integer
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: TABLE "user"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public."user" IS 'user information';


--
-- Name: user_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_seq OWNER TO postgres;

--
-- Name: user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."user" ALTER COLUMN user_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.address (address_id, address, city, county, post_code) FROM stdin;
\.
COPY public.address (address_id, address, city, county, post_code) FROM '$$PATH$$/3516.dat';

--
-- Data for Name: book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book (book_id, title, author, isbn, publisher) FROM stdin;
\.
COPY public.book (book_id, title, author, isbn, publisher) FROM '$$PATH$$/3520.dat';

--
-- Data for Name: borrowing; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.borrowing (borrowing_id, borrowed_timestamp, due_timestamp, book_id, user_id, returned) FROM stdin;
\.
COPY public.borrowing (borrowing_id, borrowed_timestamp, due_timestamp, book_id, user_id, returned) FROM '$$PATH$$/3522.dat';

--
-- Data for Name: contact_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_information (contact_information_id, primary_phone_number, alternative_email) FROM stdin;
\.
COPY public.contact_information (contact_information_id, primary_phone_number, alternative_email) FROM '$$PATH$$/3518.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (user_name, password_salt, password_hash, email_address, user_id, address_id, contact_information_id) FROM stdin;
\.
COPY public."user" (user_name, password_salt, password_hash, email_address, user_id, address_id, contact_information_id) FROM '$$PATH$$/3512.dat';

--
-- Name: address_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.address_address_id_seq', 1, true);


--
-- Name: book_book_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.book_book_id_seq', 2, true);


--
-- Name: borrowing_borrowing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.borrowing_borrowing_id_seq', 1, true);


--
-- Name: contact_information_contact_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contact_information_contact_information_id_seq', 1, true);


--
-- Name: user_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_seq', 51, true);


--
-- Name: user_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_user_id_seq', 2, true);


--
-- Name: address adress_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT adress_pk PRIMARY KEY (address_id);


--
-- Name: book book_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_pk PRIMARY KEY (book_id);


--
-- Name: borrowing borrowing_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.borrowing
    ADD CONSTRAINT borrowing_pk PRIMARY KEY (borrowing_id);


--
-- Name: contact_information contact_information_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_information
    ADD CONSTRAINT contact_information_pk PRIMARY KEY (contact_information_id);


--
-- Name: user password_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT password_unique UNIQUE (password_salt, password_hash);


--
-- Name: user user_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pk PRIMARY KEY (user_id);


--
-- Name: borrowing borrowing_book_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.borrowing
    ADD CONSTRAINT borrowing_book_fk FOREIGN KEY (book_id) REFERENCES public.book(book_id);


--
-- Name: borrowing borrowing_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.borrowing
    ADD CONSTRAINT borrowing_user_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id);


--
-- Name: user user_address_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_address_fk FOREIGN KEY (address_id) REFERENCES public.address(address_id);


--
-- Name: user user_contact_information_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_contact_information_fk FOREIGN KEY (contact_information_id) REFERENCES public.contact_information(contact_information_id);


--
-- PostgreSQL database dump complete
--

